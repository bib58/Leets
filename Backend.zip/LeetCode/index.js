const express = require('express')
require('dotenv').config();
const main = require('./config/database')
const cookieParser = require('cookie-parser');
const redisClient = require('./config/redis');
const problemRouter = require("./routes/problemCreator");
const authRouter = require("./routes/userAuth");
const cors = require('cors')
// const submitRouter = require("./routes/submit")
// const aiRouter = require("./routes/aiChatting")
// const videoRouter = require("./routes/videoCreator");

const app = express();

app.use(cors({
    origin: ["http://localhost:5173", "http://127.0.0.1:5173"],
    credentials: true
}));


app.use(express.json());
app.use(cookieParser());


app.use('/user', authRouter);
// app.use('/problem',problemRouter);
// app.use('/submission',submitRouter);
// app.use('/ai',aiRouter);
// app.use("/video",videoRouter);


const InitalizeConnection = async () => {
    try {
        // await Promise.all([main(), redisClient.connect()]);
        await main();
        console.log("DataBase Connected");

        app.listen(process.env.PORT, () => console.log("Server listening at port number: " + process.env.PORT))
    }
    catch (err) {
        console.log("Error in connecting to DataBase: " + err);
    }
}


InitalizeConnection();
