const redisClient = require("../config/redis")

const rateLimitMiddleware = async (req, res, next) => {
    const userId = req.user.id;
    const redisKey = `rate_limit_${userId}`;

    try {
        const exists = await redisClient.exists(redisKey);
        if (exists)  return res.status(429).send("Too many requests - try again later");

        await redisClient.set(redisKey, 'coolDown', {
            EX: 10, // Expire after 10 seconds
            NX: true // Only set the key if it does not already exist
        });

        next();
    }
    catch (error) {
        res.status(500).send("Rate limiting error:", error);
    }
}


module.exports = rateLimitMiddleware;
