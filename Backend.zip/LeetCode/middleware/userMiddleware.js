// const jwt = require("jsonwebtoken");
// const User = require("../models/user");
// const redisClient = require("../config/redis")

// const userMiddleware = async (req, res, next) => {
//     try {
//         const { token } = req.cookies;

//         if (!token)  {
//             req.result = null;
//             return next();
//         }

//         const payload = jwt.verify(token, process.env.JWT_KEY);

//         const { _id } = payload;

//         if (!_id) {
//             req.result = null;
//             return next();
//         }
        
//         const result = await User.findById(_id);

//         if (!result) {
//             req.result = null;
//             return next();
//         }
        

//         /* Redis ke blockList mein present toh nahi hai */

//         const IsBlocked = await redisClient.exists(`token:${token}`);

//         if (IsBlocked) {
//             req.result = null;
//             return next();
//         }

//         req.result = result;
//         next();
//     }
//     catch (err) {
//         res.status(401).send("Error in User MiddleWare: " + err.message)
//     }
// }


// module.exports = userMiddleware;





const jwt = require("jsonwebtoken");
const User = require("../models/user");
const redisClient = require("../config/redis")

const userMiddleware = async (req, res, next) => {
    try {
        const { token } = req.cookies;

        if (!token) {
            req.result = null;
            return next();
        }

        const payload = jwt.verify(token, process.env.JWT_KEY);
        const { _id } = payload;

        if (!_id) {
            req.result = null;
            return next();
        }
        
        const result = await User.findById(_id);

        if (!result) {
            req.result = null;
            return next();
        }

        // Check if token is blocked in Redis
        const IsBlocked = await redisClient.exists(`token:${token}`);
        if (IsBlocked) {
            req.result = null;
            return next();
        }

        req.result = result;
        next();
    }
    catch (err) {
        console.log("Middleware error:", err.message);
        req.result = null;
        next();
    }
}

module.exports = userMiddleware;