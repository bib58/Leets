const validator = require("validator");

const validate = (data) => {
    console.log("Validating data:", data);

    const mandatoryFields = ['firstName', 'emailId', 'password'];
    const missingFields = mandatoryFields.filter(field => !data[field]);

    if (missingFields.length > 0) {
        throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
    }

    if (!validator.isEmail(data.emailId)) {
        throw new Error("Invalid Email format");
    }

    if (!validator.isStrongPassword(data.password)) {
        throw new Error("Password must be at least 8 characters long and contain uppercase, lowercase, number, and special character");
    }

    console.log("Validation passed");
}

module.exports = validate;