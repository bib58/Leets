const User = require("../models/user")
const validate = require('../utils/validate');
const bcrypt = require("bcrypt");
const jwt = require('jsonwebtoken');
const redisClient = require("../config/redis");
const Submission = require("../models/submission")


// const register = async (req, res) => {
//     try {
//         validate(req.body);
//         const { firstName: firstname, mail: emailId, pass: password } = req.body;


//         /* To add everyone as user whether he mentions him as role: 'admin' */
//         const userData = {
//             firstname,
//             emailId,
//             password: await bcrypt.hash(password, 10),
//             role: 'user'
//         };

//         const user = await User.create(userData);

//         const token = jwt.sign({ _id: user._id, emailId: emailId, role: 'user' }, process.env.JWT_KEY, { expiresIn: 60 * 60 * 100 }); // token comes in seconds 

//         const reply = {
//             firstname: user.firstname,
//             emailId: user.emailId,
//             _id: user._id,
//             role: user.role,
//         }

//         res.cookie('token', token, { maxAge: 60 * 60 * 1000 * 100 }); // cookie comes in milliseconds
//         res.status(201).json({
//             user: reply,
//             message: "Registered Successfully"
//         })
//     }
//     catch (err) {
//         res.status(400).send("Error in register: " + err.message);
//     }
// }


// const login = async (req, res) => {
//     try {
//         const { mail: emailId, pass: password } = req.body;

//         if (!emailId) throw new Error("Email is required");
//         if (!password) throw new Error("Password is required");

//         const user = await User.findOne({ emailId });
//         if (!user) throw new Error("User not found");

//         const match = await bcrypt.compare(password, user.password);
//         if (!match) throw new Error("Invalid Credentials");

//         const reply = {
//             firstname: user.firstname,
//             emailId: user.emailId,
//             _id: user._id,
//             role: user.role,
//         }

//         const token = jwt.sign({ _id: user._id, emailId: emailId, role: user.role }, process.env.JWT_KEY, { expiresIn: 60 * 60 * 100 });
//         res.cookie('token', token, { maxAge: 60 * 60 * 1000 * 100 });
//         res.status(200).json({
//             user: reply,
//             message: "Login Successful"
//         })
//     }
//     catch (err) {
//         res.status(401).send("Error in logging " + err);
//     }
// }



const register = async (req, res) => {
    try {
        console.log("=== REGISTRATION REQUEST ===");
        console.log("Request body:", req.body);
        
        // Use exact field names from frontend
        const userData = {
            firstName: req.body.firstName,
            emailId: req.body.emailId,
            password: req.body.password
        };

        console.log("Processed user data:", userData);

        // Validate the data
        validate(userData);

        // Check if user already exists
        const existingUser = await User.findOne({ emailId: userData.emailId });
        if (existingUser) {
            throw new Error("User with this email already exists");
        }

        // Hash password
        userData.password = await bcrypt.hash(userData.password, 10);
        userData.role = 'user';

        console.log("Creating user with data:", userData);
        const user = await User.create(userData);
        console.log("User created successfully:", user._id);
        
        const token = jwt.sign(
            { _id: user._id, emailId: user.emailId, role: user.role }, 
            process.env.JWT_KEY, 
            { expiresIn: '100h' }
        );

        const reply = {
            firstName: user.firstName,
            emailId: user.emailId,
            _id: user._id,
            role: user.role,
        };

        res.cookie('token', token, { 
            maxAge: 100 * 60 * 60 * 1000,
            httpOnly: true,
            secure: false,
            sameSite: 'lax'
        });
        
        console.log("Registration successful for:", user.emailId);
        res.status(201).json({
            user: reply,
            message: "Registered Successfully"
        });
    }
    catch (err) {
        console.log("❌ Registration error:", err.message);
        res.status(400).json({ 
            message: err.message 
        });
    }
}

const login = async (req, res) => {
    try {
        const { emailId, password } = req.body;

        if (!emailId || !password) {
            throw new Error("Email and password are required");
        }

        const user = await User.findOne({ emailId });
        if (!user) {
            throw new Error("User not found");
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            throw new Error("Invalid credentials");
        }

        const reply = {
            firstName: user.firstName,
            emailId: user.emailId,
            _id: user._id,
            role: user.role,
        };

        const token = jwt.sign(
            { _id: user._id, emailId: emailId, role: user.role }, 
            process.env.JWT_KEY, 
            { expiresIn: '100h' }
        );
        
        res.cookie('token', token, { 
            maxAge: 100 * 60 * 60 * 1000,
            httpOnly: true,
            secure: false,
            sameSite: 'lax'
        });
        
        res.status(200).json({
            user: reply,
            message: "Login Successful"
        });
    }
    catch (err) {
        console.log("Login error:", err.message);
        res.status(401).json({ 
            message: err.message 
        });
    }
}

// ... rest of the functions remain the same


const logout = async (req, res) => {
    try {
        const { token } = req.cookies;
        const payload = jwt.decode(token);

        await redisClient.set(`token:${token}`, 'Blocked');
        await redisClient.expireAt(`token:${token}`, payload.exp);

        res.cookie("token", null, { expires: new Date(Date.now()) });
        res.send("Logged Out Succesfully");
    }
    catch (err) {
        res.status(503).send("Error: " + err);
    }
}


const adminRegister = async (req, res) => {
    try {
        validate(req.body);
        const { firstName, emailId, password } = req.body;

        req.body.password = await bcrypt.hash(password, 10);

        const user = await User.create(req.body);
        const token = jwt.sign({ _id: user._id, emailId: emailId, role: user.role }, process.env.JWT_KEY, { expiresIn: 60 * 60 });
        res.cookie('token', token, { maxAge: 60 * 60 * 1000 });
        res.status(201).send("User Registered Successfully");
    }
    catch (err) {
        res.status(400).send("Error: " + err);
    }
}


const deleteProfile = async (req, res) => {
    try {
        const userId = req.result._id;

        await User.findByIdAndDelete(userId);

        await Submission.deleteMany({ userId });

        res.status(200).send("Deleted Successfully");
    }
    catch (err) {
        res.status(500).send("Internal Server Error");
    }
}


module.exports = { register, login, logout, adminRegister, deleteProfile };
