// const express = require('express');
// const authRouter = express.Router();

// const { register, login, logout, adminRegister, deleteProfile } = require('../controllers/authenticate')
// const userMiddleware = require("../middleware/userMiddleware");
// const adminMiddleware = require('../middleware/adminMiddleware');

// authRouter.post('/register', register);
// authRouter.post('/login', login);
// authRouter.post('/logout', userMiddleware, logout);
// authRouter.post('/admin/register', adminMiddleware, adminRegister);
// authRouter.delete('/deleteProfile', userMiddleware, deleteProfile);

// authRouter.get('/check', userMiddleware, (req, res) => {
//     if (!req.result) {
//         return res.status(200).json({
//             user: null,
//             message: "No active session"
//         });
//     }
    
//     const reply = {
//         firstName: req.result.firstName,
//         emailId: req.result.emailId,
//         _id: req.result._id,
//         role: req.result.role,
//     }
//     res.status(200).json({
//         user: reply,
//         message: "Valid User"
//     });
// })

// module.exports = authRouter;





const express = require('express');
const authRouter = express.Router();

const { register, login, logout, adminRegister, deleteProfile } = require('../controllers/authenticate')
const userMiddleware = require("../middleware/userMiddleware");
const adminMiddleware = require('../middleware/adminMiddleware');

authRouter.post('/register', register);
authRouter.post('/login', login);
authRouter.post('/logout', userMiddleware, logout);
authRouter.post('/admin/register', adminMiddleware, adminRegister);
authRouter.delete('/deleteProfile', userMiddleware, deleteProfile);

authRouter.get('/check', userMiddleware, (req, res) => {
    if (!req.result) {
        return res.status(200).json({
            user: null,
            message: "No active session"
        });
    }
    
    const reply = {
        firstName: req.result.firstName,
        emailId: req.result.emailId,
        _id: req.result._id,
        role: req.result.role,
    };
    
    console.log('Check endpoint - User found:', reply.emailId);
    res.status(200).json({
        user: reply,
        message: "Valid User"
    });
});

module.exports = authRouter;