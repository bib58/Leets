const express = require('express');
const submitRouter = express.Router();
const userMiddleware = require("../middleware/userMiddleware");
const rateLimitMiddleware = require("../middleware/rateLimitMiddleware");
const { submitCode, runCode } = require("../controllers/userSubmission");

submitRouter.post("/submit/:id", userMiddleware, rateLimitMiddleware, submitCode);
submitRouter.post("/run/:id", userMiddleware, rateLimitMiddleware, runCode);

module.exports = submitRouter;